from django.contrib import admin
from .models import hotel, quarto

admin.site.register(hotel)
admin.site.register(quarto)